package com.directions.route;

//. by Haseem Saheed
public interface Parser {
    public Route parse();
}