package com.example.selfie.utils;

/**
 * Created by dpavlov on 8.7.2014 г..
 */
public enum Order {
    RANDOMIZED,
    ORDERED;
}
